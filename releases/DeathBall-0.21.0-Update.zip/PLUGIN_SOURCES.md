# 同梱外部プラグインの取得元

- ZNPCsPlus 2.1.0-SNAPSHOT build267: 公式 https://ci.pyr.lol/job/ZNPCsPlus/267/ 、ソース https://github.com/Pyrbu/ZNPCsPlus/tree/2.X 。1.21.11対応を実Paper132とprotocol774で検証しました。
- DecentHolograms 2.10.1: ユーザー添付JARをそのまま収録。プロジェクト https://github.com/DecentSoftware-eu/DecentHolograms 。

元のJAR内の著作権・ライセンス等のファイルを保持しています。外部プラグインのJARを改変していません。DeathBallCoreはソースZIPを収録しています。
