import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import javax.imageio.ImageIO;

/** Java 21, no dependencies. Reads a local pack; creates a separate native-UV overlay. */
public final class MakeNativeSkinOverlay {
    static final String PREFIX="assets/deathball/textures/entity/npc/";
    static final String[] NAMES={"yoriichi_hd","toji"};
    // Official Minecraft 1.21.11 SkinTextureDownloader: x,y,offsetX,offsetY,w,h.
    // All twelve rectangles mirror X; their legacy 64x32 coordinates scale by eight.
    static final int[][] RECTS={{4,16,16,32,4,4},{8,16,16,32,4,4},{0,20,24,32,4,12},
        {4,20,16,32,4,12},{8,20,8,32,4,12},{12,20,16,32,4,12},
        {44,16,-8,32,4,4},{48,16,-8,32,4,4},{40,20,0,32,4,12},
        {44,20,-8,32,4,12},{48,20,-16,32,4,12},{52,20,-8,32,4,12}};
    static final String META="{\"pack\":{\"pack_format\":75,\"min_format\":[75,0],\"max_format\":[75,0],\"description\":\"DeathBall native HD skin UV compatibility (1.21.11)\"}}\n";
    static int checks;
    public static void main(String[] args) throws Exception {
        ImageIO.setUseCache(false);
        if(args.length==1&&args[0].equals("--self-test")){selfTest();return;}
        if(args.length<2||args.length>3||args.length==3&&!args[2].equals("--vanilla-alpha")){
            System.err.println("Usage: java -jar DeathBall-SkinCompat.jar input-pack.zip output-overlay.zip [--vanilla-alpha]\n       java -jar DeathBall-SkinCompat.jar --self-test");System.exit(2);return;
        }
        try{convert(Path.of(args[0]),Path.of(args[1]),args.length==3);}
        catch(Exception e){System.err.println("Conversion failed: "+e.getMessage());System.exit(1);return;}
        System.out.println("Created "+Path.of(args[1]).toAbsolutePath()+". Enable this overlay ABOVE the unchanged original pack.");
        System.out.println("Resolution: 512x512; no resampling. Alpha: "+(args.length==3?"official legacy normalization (RGB retained)":"original upper-half RGBA retained"));
    }
    static BufferedImage expand(BufferedImage source,boolean vanillaAlpha){
        if(source.getWidth()!=512||source.getHeight()!=256)throw new IllegalArgumentException("Expected a 512x256 legacy skin; got "+source.getWidth()+"x"+source.getHeight());
        BufferedImage result=new BufferedImage(512,512,BufferedImage.TYPE_INT_ARGB);
        result.setRGB(0,0,512,256,source.getRGB(0,0,512,256,null,0,512),0,512);
        for(int[] r:RECTS){int sx=r[0]*8,sy=r[1]*8,dx=(r[0]+r[2])*8,dy=(r[1]+r[3])*8,w=r[4]*8,h=r[5]*8;
            for(int y=0;y<h;y++)for(int x=0;x<w;x++)result.setRGB(dx+w-1-x,dy+y,source.getRGB(sx+x,sy+y));}
        if(vanillaAlpha){opaque(result,0,0,32,16);boolean clearHat=true;
            for(int y=0;y<256&&clearHat;y++)for(int x=256;x<512;x++)if((result.getRGB(x,y)>>>24)<128){clearHat=false;break;}
            if(clearHat)for(int y=0;y<256;y++)for(int x=256;x<512;x++)result.setRGB(x,y,result.getRGB(x,y)&0xffffff);
            opaque(result,0,16,64,32);opaque(result,16,48,48,64);
        }
        return result;
    }
    static void opaque(BufferedImage image,int x0,int y0,int x1,int y1){for(int y=y0*8;y<y1*8;y++)for(int x=x0*8;x<x1*8;x++)image.setRGB(x,y,image.getRGB(x,y)|0xff000000);}
    static byte[] png(BufferedImage image) throws IOException {var bytes=new ByteArrayOutputStream();if(!ImageIO.write(image,"png",bytes))throw new IOException("PNG encoder unavailable");return bytes.toByteArray();}
    static String sha(byte[] data) throws Exception {return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));}
    static String sha(Path file) throws Exception {var digest=MessageDigest.getInstance("SHA-256");try(var in=Files.newInputStream(file)){byte[] buffer=new byte[65536];for(int n;(n=in.read(buffer))>=0;)digest.update(buffer,0,n);}return HexFormat.of().formatHex(digest.digest());}
    static long crc(byte[] data){var crc=new CRC32();crc.update(data);return crc.getValue();}
    static byte[] read(ZipFile zip,ZipEntry entry) throws IOException {if(entry==null)throw new IOException("Missing required entry");if(entry.getSize()>16*1024*1024)throw new IOException("Unexpectedly large PNG entry");byte[] data;
        try(var in=zip.getInputStream(entry)){data=in.readNBytes(16*1024*1024+1);}if(data.length>16*1024*1024||crc(data)!=entry.getCrc())throw new IOException("ZIP CRC/size check failed: "+entry.getName());return data;}
    static void convert(Path input,Path output,boolean vanillaAlpha) throws Exception {
        input=input.toAbsolutePath().normalize();output=output.toAbsolutePath().normalize();
        if(Files.exists(output)||input.equals(output))throw new IOException("Output already exists; choose a new filename (input will never be overwritten)");
        String sourceHash=sha(input);var entries=new LinkedHashMap<String,byte[]>();entries.put("pack.mcmeta",META.getBytes(StandardCharsets.UTF_8));
        StringBuilder report=new StringBuilder("DeathBall native HD skin overlay for Java 1.21.11 / resource pack 75.0\nEnable above the original pack; keep the original pack enabled.\nOnly Yoriichi/Toji texture paths are overridden; the original ZIP is unchanged.\nNo downsampling; original upper-half "+(vanillaAlpha?"RGB retained; alpha normalized using vanilla legacy rules":"RGBA pixels retained exactly")+".\ninput_pack_sha256="+sourceHash+"\n");
        try(var zip=new ZipFile(input.toFile())){
            if(zip.getEntry("pack.mcmeta")==null)throw new IOException("Input must be the inner resource-pack ZIP with pack.mcmeta at its root");
            var seen=new HashSet<String>();for(var enumeration=zip.entries();enumeration.hasMoreElements();){String name=enumeration.nextElement().getName();if(!seen.add(name))throw new IOException("Duplicate ZIP entry: "+name);}
            for(String name:NAMES){String path=PREFIX+name+".png";var entry=zip.getEntry(path);if(entry==null)throw new IOException("Missing "+path);byte[] original=read(zip,entry);
                if(original.length<8||original[0]!=(byte)137||original[1]!=80||original[2]!=78||original[3]!=71)throw new IOException("Expected PNG: "+path);
                var source=ImageIO.read(new ByteArrayInputStream(original));if(source==null)throw new IOException("Cannot decode PNG: "+path);
                byte[] compatible=png(expand(source,vanillaAlpha));entries.put(path,compatible);
                report.append(path).append(" source_sha256=").append(sha(original)).append(" output_sha256=").append(sha(compatible)).append(" output_crc32=").append(Long.toHexString(crc(compatible))).append('\n');
            }
        }
        entries.put("SKIN-COMPATIBILITY.txt",report.toString().getBytes(StandardCharsets.UTF_8));
        if(!sourceHash.equals(sha(input)))throw new IOException("Input changed while reading; no output written");
        boolean created=false;
        try{var stream=Files.newOutputStream(output,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);created=true;
            try(var zip=new ZipOutputStream(stream)){for(var entry:entries.entrySet()){var item=new ZipEntry(entry.getKey());item.setTime(0);zip.putNextEntry(item);zip.write(entry.getValue());zip.closeEntry();}}
            try(var zip=new ZipFile(output.toFile())){for(var e=zip.entries();e.hasMoreElements();)read(zip,e.nextElement());}
        }catch(Exception e){if(created)Files.deleteIfExists(output);throw e;}
    }
    static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);checks++;}
    static void expectFailure(Path input,Path output,String label) throws Exception {boolean failed=false;try{convert(input,output,false);}catch(IOException|IllegalArgumentException e){failed=true;}check(failed,label);}
    static void syntheticPack(Path path,BufferedImage image,boolean includeToji) throws Exception {
        try(var zip=new ZipOutputStream(Files.newOutputStream(path))){var entries=new LinkedHashMap<String,byte[]>();entries.put("pack.mcmeta",META.getBytes(StandardCharsets.UTF_8));entries.put(PREFIX+"yoriichi_hd.png",png(image));if(includeToji)entries.put(PREFIX+"toji.png",png(image));
            for(var entry:entries.entrySet()){zip.putNextEntry(new ZipEntry(entry.getKey()));zip.write(entry.getValue());zip.closeEntry();}}
    }
    static void selfTest() throws Exception {
        BufferedImage source=new BufferedImage(512,256,BufferedImage.TYPE_INT_ARGB);
        for(int y=0;y<256;y++)for(int x=0;x<512;x++)source.setRGB(x,y,0xff000000|(y<<9)|x);
        var output=expand(source,false);check(output.getWidth()==512&&output.getHeight()==512,"full-resolution square output");
        for(int y=0;y<256;y++)for(int x=0;x<512;x++)check(output.getRGB(x,y)==source.getRGB(x,y),"original RGBA pixel unchanged");
        boolean[][] written=new boolean[512][256];
        // Independent destination/origin atlas coordinates from official twelve face mappings.
        int[][] faces={{20,48,4,16,4,4},{24,48,8,16,4,4},{24,52,0,20,4,12},{20,52,4,20,4,12},{16,52,8,20,4,12},{28,52,12,20,4,12},
            {36,48,44,16,4,4},{40,48,48,16,4,4},{40,52,40,20,4,12},{36,52,44,20,4,12},{32,52,48,20,4,12},{44,52,52,20,4,12}};
        for(int[] f:faces)for(int y=0;y<f[5]*8;y++)for(int x=0;x<f[4]*8;x++){int dx=f[0]*8+x,dy=f[1]*8+y;check(!written[dx][dy-256],"mirrored face targets do not overlap");written[dx][dy-256]=true;check(output.getRGB(dx,dy)==source.getRGB(f[2]*8+f[4]*8-1-x,f[3]*8+y),"mirrored pixel maps to correct source");}
        for(int y=256;y<512;y++)for(int x=0;x<512;x++)if(!written[x][y-256])check(output.getRGB(x,y)==0,"unused lower half transparent");
        var normalized=expand(source,true);check((normalized.getRGB(260,10)>>>24)==0,"opaque legacy hat is cleared");check(normalized.getRGB(260,140)==source.getRGB(260,140),"legacy body made opaque after hat clearing");
        source.setRGB(260,10,0x01020304);normalized=expand(source,true);check(normalized.getRGB(260,10)==0x01020304,"existing transparent hat alpha retained");
        Path dir=Files.createTempDirectory("deathball-skin-tool-test-");
        try{Path input=dir.resolve("original.zip"),pack=dir.resolve("overlay.zip"),again=dir.resolve("again.zip");syntheticPack(input,source,true);String originalHash=sha(input);convert(input,pack,false);convert(input,again,false);
            check(originalHash.equals(sha(input)),"input ZIP bytes unchanged");check(sha(pack).equals(sha(again)),"deterministic output ZIP");
            try(var zip=new ZipFile(pack.toFile())){check(zip.size()==4,"only two textures and metadata included");check(new String(read(zip,zip.getEntry("pack.mcmeta")),StandardCharsets.UTF_8).equals(META),"resource pack version 75.0 metadata");
                for(String name:NAMES){var image=ImageIO.read(new ByteArrayInputStream(read(zip,zip.getEntry(PREFIX+name+".png"))));check(image.getWidth()==512&&image.getHeight()==512,"ZIP PNG square UV");}}
            String outputHash=sha(pack);expectFailure(input,pack,"existing output rejected");check(outputHash.equals(sha(pack)),"existing output never overwritten");expectFailure(input,input,"input/output same path rejected");check(originalHash.equals(sha(input)),"input survives overwrite attempt");
            Path missing=dir.resolve("missing.zip"),bad=dir.resolve("bad.zip"),failed=dir.resolve("failed.zip");syntheticPack(missing,source,false);expectFailure(missing,failed,"missing skin rejected");check(!Files.exists(failed),"missing input produces no output");
            syntheticPack(bad,new BufferedImage(512,512,BufferedImage.TYPE_INT_ARGB),true);expectFailure(bad,failed,"wrong UV dimensions rejected");check(!Files.exists(failed),"wrong UV produces no output");
        }finally{try(var files=Files.walk(dir)){for(Path path:files.sorted(Comparator.reverseOrder()).toList())Files.delete(path);}}
        System.out.println("PASS native skin overlay synthetic regression: "+checks+" checks. No user images processed.");
    }
}
