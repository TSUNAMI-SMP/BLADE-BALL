# 縁一・甚爾のHDスキン互換ツール

`DeathBall-SkinCompat.jar` はJava21で動く小さな補助ツールです。お手元のV0.20.1統合リソースパックを読み、縁一と甚爾の512×256画像を現行Mannequin用の512×512 UVへ補完した、別の小さなリソースパックを作ります。縮小せず、上半分の元RGBAピクセルを保持し、左手足の面をMinecraft公式の12矩形に従って反転コピーします。

## 実行方法

更新セットを展開したフォルダーで、次のコマンドを実行してください。元パックの場所が違う場合は、入力ZIPをフルパスで指定できます。

```text
java -jar tools/DeathBall-SkinCompat.jar "DeathBall_ResourcePack-0.20.1-1.21.11.zip" "DeathBall-NativeSkinOverlay.zip"
```

1. 入力は `pack.mcmeta` がZIP直下にある統合リソースパック本体です。説明画像やGLBが入った外側の説明ZIPではありません。
2. 出力の `DeathBall-NativeSkinOverlay.zip` をMinecraftの `resourcepacks` に入れます。
3. 元の0.20.1統合パックも有効にしたまま、互換オーバーレイをその上に配置します。

入力パックは変更しません。出力が既に存在する場合は上書きせず停止するので、新しい出力名を指定してください。ZIPには次の2テクスチャとメタデータ・検証用ハッシュ説明だけを収録します。

```text
assets/deathball/textures/entity/npc/yoriichi_hd.png
assets/deathball/textures/entity/npc/toji.png
```

ほかの5キャラ、既存CPU、剣・3Dモデル・音声は元の統合パックから読みます。プラグインのテクスチャIDは変更しません。

元の画像の透過処理も古いMinecraftスキンと同じ動作に合わせたい場合は、末尾に `--vanilla-alpha` を付けられます。このオプションではRGBを保持し、ベース部位の不透明化と旧帽子領域の透過を適用するため、alpha値は変化します。通常の実行では元の上半分のRGBAをそのまま保持します。

## 検証した範囲

合成座標グリッドで290,834項目成功しました。元の上半分のピクセル、12面の反転座標、未使用部分の透過、オプションの透過処理、入力ZIPのハッシュ不変、出力CRCと決定性、重複出力・欠落・誤った寸法の拒否を検査しています。

このクラウドには元の0.20.1パックと新PNGの実体が無いため、実素材を変換済みのオーバーレイは収録していません。ユーザーの原画やMinecraftでの実表示は未検証です。実行後に縁一・甚爾の見た目をクライアントで確認してください。

自己テストは `java -jar tools/DeathBall-SkinCompat.jar --self-test`、ソースは `MakeNativeSkinOverlay.java` です。
